//
//  ViewController.swift
//  DemoApp
//
//  Created by Chas Shipman on 9/13/18.
//  Copyright © 2018 Chas Shipman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textLabel: UILabel!
    
    var backgroundColor: UIColor!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        backgroundColor = view.backgroundColor // helps to reset background color
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func textChangeButton(_ sender: Any) {
        
        /*following code lets us type in text field and change text*/
        
        if(textField.text == ""){ //if textField is empty say Goodbye
            textLabel.text = "Goodbye 👋"
        }
            
        else {
            textLabel.text = textField.text //changes text to what is typed        }
            textLabel.numberOfLines = 0 //wraps text: stack overflow
        }
        
        textField.text = "" //empties text field after typing
        view.endEditing(true)//closes keyboard
    }
    
    @IBAction func viewColorButton(_ sender: Any) {
        view.backgroundColor = UIColor.black
    }
    
   
    @IBAction func textColorButton(_ sender: Any) {
        textLabel.textColor = UIColor.orange
    }
    
    
    
    @IBAction func resetGesture(_ sender: Any) {
        textLabel.text = "Hello from Chas!"
        view.backgroundColor = backgroundColor
        textLabel.textColor = UIColor.white
    }
    
    
}

